#include "p1b.h"

int main()
{
    printSize();
    printStaticArraySize();
    printDynamicArraySize();
    printPointerArraySize();
}
