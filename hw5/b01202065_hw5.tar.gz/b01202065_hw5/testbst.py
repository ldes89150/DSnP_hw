import os
import time
import subprocess
do = '''adtr 10
usage
adta -r {0}
usage
'''

for i in range(9):
    print do.format(10**i)
print '''q -f
'''
